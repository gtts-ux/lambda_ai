"""Lambda AI terminal application."""

__version__ = "0.10.0"
