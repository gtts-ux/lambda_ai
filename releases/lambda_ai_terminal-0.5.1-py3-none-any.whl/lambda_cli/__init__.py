"""Lambda AI terminal application."""

__version__ = "0.5.1"
